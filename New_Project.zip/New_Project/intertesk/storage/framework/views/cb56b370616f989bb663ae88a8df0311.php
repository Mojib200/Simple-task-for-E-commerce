
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-titles">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item"><a href="javascript:void(0)"> Sub Category </a></li>
            </ol>
        </div>

        <div class="row">
            <div class="col-sm-4">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_subproduct')): ?>
                    <div class="card text-white bg-success mb-3">
                        <div class="card-header  text-white">
                            <h1>Add Sub Category</h1>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('sub.category.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for=""class="form-label">Category Name </label>
                                    <select name="category_id" class="form-label">
                                        <option value="">-- Select Category ---</option>
                                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label for=""class="form-label">Sub Category Name </label>
                                    <input type="text" class="form-control" name="sub_category_name">
                                </div>
                                <?php $__errorArgs = ['sub_category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="mb-3">
                                    <label for=""class="form-label">Sub Category Image </label>
                                    <input type="file" class="form-control" name="sub_category_image">
                                </div>

                                <?php $__errorArgs = ['sub_category_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="mb-3 pt-2">
                                    <button class="btn btn-primary" type="submit">Add Sub Category</button>
                                </div>
                            </form>

                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-lg-8">
                <div class="card">

                    <div class="card-header">
                        <h1 class="text-center">View Sub Category</h1>

                    </div>
                    <div class="card-body ">
                        <table class="table table-dark text-center table table-striped" id="myTable">
                            <thead>
                                <tr>
                                    
                                    <th>Sub Category Name</th>
                                    <th>Picture</th>
                                    <th>Category name </th>
                                    <th>Added By </th>
                                    <th>Action</th>
                                    <th>Create At</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $sub_categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($sub_category->sub_category_name); ?></td>
                                        <td><img src="<?php echo e(asset('/subcategory')); ?>/<?php echo e($sub_category->sub_category_image); ?>"
                                                alt="" width="50" height="50"></td>
                                        <td><?php echo e($sub_category->relation_to_sub_category->category_name); ?></td>

                                        <td><?php echo e($sub_category->relation_to_user->name); ?></td>

                                        <td>
                                            <div class="mb-2"> <a
                                                    href="<?php echo e(route('sub.category.delete', $sub_category->id)); ?>"class="btn btn-danger">Delete</a>
                                            </div>
                                        </td>

                                        <td><?php echo e($sub_category->created_at->diffForHumans()); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>


            </div>

        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('dashbroad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Office\New_Project\intertesk\resources\views/backend/subcategory.blade.php ENDPATH**/ ?>