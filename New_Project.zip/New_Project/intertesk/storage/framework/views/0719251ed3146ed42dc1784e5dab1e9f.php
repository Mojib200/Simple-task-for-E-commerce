
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-titles">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item"><a href="javascript:void(0)"> Role Manager</a></li>
            </ol>
        </div>
    </div>

        <div class="row">

            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h3>Edit Role</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('role_edit_update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="" class="form-label">Edit Role Name</label>
                                <input type="text" readonly class="form-control" value="<?php echo e($role_info->name); ?>">
                                <input type="hidden"  class="form-control" name="role_id" value="<?php echo e($role_info->id); ?>">
                            </div>
                            <div class="mb-3">
                                <h5>Select Permission</h5>
                                <div class="form-group">
                                    <?php $__currentLoopData = $permission_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check form-check-inline">
                                            <label class="form-check-label">
                                                <input type="checkbox" multiple <?php echo e(($role_info->hasPermissionTo($permission_info->name))?'checked':''); ?> name="permissions[]" class="form-check-input"
                                                    value="<?php echo e($permission_info->name); ?>"><?php echo e($permission_info->name); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">Update Role</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>

        </div>
  
    <div class="row">
       
            <div class="col-lg-12">
                <div class="card">

                    <div class="card-header">
                        <h1 class="text-center">Role List</h1>

                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th>SL</th>
                                <th>Role</th>
                                <th>Permission</th>
                                <th>Action</th>
                            </tr>
                            
                        </table>
                    </div>
                </div>
            </div>
      


        <div class="col-lg-12">
            <div class="card">

                <div class="card-header">
                    <h1 class="text-center">User List</h1>

                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <tr>
                            <th>User</th>
                            <th>Role</th>
                            <th>Action</th>
                        </tr>
                      
                       
                    </table>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashbroad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Office\New_Project\intertesk\resources\views/backend/edit_role.blade.php ENDPATH**/ ?>