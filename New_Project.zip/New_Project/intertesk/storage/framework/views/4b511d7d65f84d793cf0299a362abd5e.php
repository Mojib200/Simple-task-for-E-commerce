
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-titles">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item"><a href="javascript:void(0)"> Product </a></li>
            </ol>
        </div>

        <div class="row">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_product')): ?>
                <div class="col-lg-12">
                    <div class="card bg-danger text-primary">
                        <div class="card-header">
                            <h1> ---Product Information--- </h1>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('product.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 mb-3">
                                        <label for=""class="form-label">Product Category Name </label>
                                        <select name="category_id" class="form-control" id="category_id">
                                            <option value="">---Select Category Name---</option>
                                            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label for=""class="form-label">Product Category Name </label>
                                        <select name="subcategory_id" class="form-control " id="subcategory_name">
                                            <option value="">---Select Category Name---</option>
                                            <?php $__currentLoopData = $sub_categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_categorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($sub_categorys->id); ?>">
                                                    <?php echo e($sub_categorys->sub_category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>



                                    <div class="col-lg-4 mb-3">
                                        <label for=""class="form-label">Product name</label>
                                        <input type="text" class="form-control" name="product_name">
                                    </div>
                                    <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                    <div class=" col-lg-4 mb-3">
                                        <label for=""class="form-label">Product Slug</label>
                                        <input type="text" class="form-control" name="product_slug">
                                    </div>
                                    <?php $__errorArgs = ['product_slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <div class="col-lg-4 mb-3">
                                        <label for=""class="form-label">Product Reguler Price</label>
                                        <input type="number" class="form-control" name="product_reguler_price">
                                    </div>
                                    <?php $__errorArgs = ['product_reguler_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



                                    <div class="col-lg-4 mb-3">
                                        <label for=""class="form-label">Product Discount % </label>
                                        <input type="number" class="form-control" name="product_discount_price">
                                    </div>
                                    <?php $__errorArgs = ['product_discount_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <div class="col-lg-4 mb-3">
                                        <label for=""class="form-label">Product After Discount price</label>
                                        <input type="number" class="form-control" name="product_after_discount_price">
                                    </div>
                                    <?php $__errorArgs = ['product_after_discount_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



                                    <div class="col-lg-6 mb-3">
                                        <label for=""class="form-label">Short Description</label>
                                        <input type="text" class="form-control " name="short_description">
                                    </div>
                                    <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <div class="col-lg-6 mb-3">
                                        <label for=""class="form-label">Long Description</label>
                                        <textarea type="text" class="form-control " id="summernote" name="long_description"></textarea>

                                    </div>
                                    <?php $__errorArgs = ['long_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                    <div class="col-lg-6 mb-3">
                                        <label for=""class="form-label">Product Preview</label>
                                        <input type="file" class="form-control" name="preview">
                                    </div>

                                    <?php $__errorArgs = ['preview'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <div class=" col-lg-6 mb-3">
                                        <label for=""class="form-label">Thumbnails</label>
                                        <input type="file" class="form-control" name="thumbnails[]" multiple>
                                    </div>


                                    <?php $__errorArgs = ['thumbnails'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                </div>

                                <div class=" col-lg-12 mb-3 pt-2">
                                    <button class="btn btn-primary" type="submit">Add Product</button>
                                </div>
                            </form>

                        </div>
                    </div>
                <?php endif; ?>
            </div>


        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h1 class="text-center">View Product</h1>
        
                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Product Name</th>
                                    <th>Regular Price</th>
                                    <th>Discount Price %</th>
                                    <th>Preview</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($product->product_name); ?></td>
                                        <td><?php echo e($product->product_reguler_price); ?></td>
                                        <td><?php echo e($product->product_discount_price == null ? 'No Discount' : $product->product_discount_price); ?>

                                        </td>
                                        <td><img src="<?php echo e(asset('/product')); ?>/<?php echo e($product->preview); ?>"
                                                alt="" width="40" height="40"></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
        
        
                        </table>
                    </div>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashbroad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Office\New_Project\intertesk\resources\views/backend\product.blade.php ENDPATH**/ ?>