

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-titles">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item"><a href="javascript:void(0)"> Category Insert/View </a></li>
        </ol>
    </div>
    <div class="row">
        <div class="col-lg-4">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_category')): ?>
            <div class="card-header">
                <h1>Add Category</h1>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('category.insert')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <div class="mb-3">
                      <label for=""class="form-label">Category Name </label>
                        <input type="text" class="form-control" name="category_name">
                    </div>
                    <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="mb-3">
                      <label for=""class="form-label">Category Image </label>
                        <input type="file" class="form-control" name="category_image">
                    </div>
                    <?php $__errorArgs = ['category_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mb-3"><?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="mb-3 pt-2">
                     <button class="btn btn-primary" type="submit">Add Category</button>
                    </div>
                </form>
        
            </div>
            <?php endif; ?>
        </div>
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h1  class="text-center">View Category</h1>

                </div>
                <div class="card-body">
                    <table class="table table-striped" >
                        <tr>
                            <th>SL</th>
                            <th>Name</th>
                            <th>Picture</th>
                            <th>Added By</th>
                            <th>Action</th>
                            <th>Create At</th>
                        </tr>
                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($category->id); ?></td>
                            <td><?php echo e($category->category_name); ?></td>
                            <td><img src="<?php echo e(asset('/categoryimage')); ?>/<?php echo e($category->category_image); ?>"
                                alt="" width="50" height="50"></td>
                            <td><?php echo e($category->relation_to_user->name); ?></td>
                            <td>
                       <div class="mb-2">  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category_delete')): ?>
                        <a href="<?php echo e(route('category.delete',$category->id)); ?>"class="btn btn-danger">Delete</a>
                        <?php endif; ?>
                    </div> </td>
                            <td><?php echo e($category->created_at); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>
                </div>
            </div>
        </div>
    </div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashbroad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Office\New_Project\intertesk\resources\views/backend/category.blade.php ENDPATH**/ ?>