
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-titles">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item"><a href="javascript:void(0)"> Role Manager</a></li>
            </ol>
        </div>
    </div>
     <div class="row">

            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h3>Add Role</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('role_create')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="" class="form-label">Role Name</label>
                                <input type="text" class="form-control" name="role_name">
                            </div>
                            <div class="mb-3">
                                <h5>Select Permission</h5>
                                <div class="form-group">
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check form-check-inline">
                                            <label class="form-check-label">
                                                <input type="checkbox" multiple name="permissions[]" class="form-check-input"
                                                    value="<?php echo e($permission->name); ?>"><?php echo e($permission->name); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">Add Role</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card">

                    <div class="card-header">
                        <h3>Assigned Role</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('assigend_role')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for=""class="form-lable">User name : </label>
                                <select name="user_id" id="" class="from-control">
                                    <option value=""> ---Select user---</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                            <div class="mb-3">
                                <label for=""class="form-lable">User Role: </label>
                                <select name="role_id" id="" class="from-control">
                                    <option value=""> ---Select User Role---</option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-info"> Assigned</button>
                            </div>

                        </form>


                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card">

                    <div class="card-header">
                        <h3>Add Permission</h3>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('permission')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for=""class="form-lable">Permission Name</label>
                                <input type="text" class="form-control" name="permission" placeholder="Permission name">
                            </div>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-info"> Permission</button>
                            </div>

                        </form>


                    </div>
                </div>
            </div>
        </div>

    <div class="row">
       
            <div class="col-lg-12">
                <div class="card">

                    <div class="card-header">
                        <h1 class="text-center">Role List</h1>

                    </div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <tr>
                                <th>SL</th>
                                <th>Role</th>
                                <th>Permission</th>
                                <th>Action</th>
                            </tr>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($role->id); ?></td>
                                    <td><?php echo e($role->name); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $role->getAllPermissions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge badge-info my-2"><?php echo e($permission->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('role_edit', $role->id)); ?>" class="btn btn-success my-2">Edit</a>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
     


        <div class="col-lg-12">
            <div class="card">

                <div class="card-header">
                    <h1 class="text-center">User List</h1>

                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <tr>
                            <th>User</th>
                            <th>Role</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td>
                                    <?php $__empty_1 = true; $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <span class="badge badge-info "> <?php echo e($role_name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        Not Assigned Yet
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('remove_user_role', $user->id)); ?>"
                                        class="btn btn-danger my-2">Remove</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashbroad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Office\New_Project\intertesk\resources\views/backend/role.blade.php ENDPATH**/ ?>